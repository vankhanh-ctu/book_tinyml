/* Copyright 2020 The TensorFlow Authors. All Rights Reserved.

  Licensed under the Apache License, Version 2.0 (the "License");
  you may not use this file except in compliance with the License.
  You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
  ==============================================================================*/

//#include <TensorFlowLite_ESP32.h>
#include <TensorFlowLite.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "audio_provider.h"
#include "main_functions.h"
#include "micro_features_model.h"
#include "feature_provider.h"
#include "micro_features_micro_model_settings.h"
#include "micro_features_yes_micro_features_data.h"
#include "tensorflow/lite/micro/micro_interpreter.h"
#include "tensorflow/lite/micro/micro_mutable_op_resolver.h"
#include "tensorflow/lite/micro/micro_op_resolver.h"
#include "tensorflow/lite/micro/all_ops_resolver.h"
#include "tensorflow/lite/schema/schema_generated.h"
//#include "FS.h"
//#include "SD.h"
//#include "SPI.h"

namespace {
tflite::ErrorReporter* error_reporter = nullptr;
const tflite::Model* model = nullptr;
tflite::MicroInterpreter* interpreter = nullptr;
TfLiteTensor* model_input = nullptr;
TfLiteTensor* output = nullptr;
FeatureProvider* feature_provider = nullptr;

constexpr int kTensorArenaSize = 30*1024;//110 * 1024
uint8_t tensor_arena[kTensorArenaSize];
int8_t feature_buffer[kFeatureElementCount];
int8_t* model_input_buffer = nullptr;
int32_t previous_time = 0;
int16_t count[4];
}

// The name of this function is important for Arduino compatibility.
void setup() {
  //setup 
  Serial.begin(115200);

  static tflite::MicroErrorReporter micro_error_reporter;
  error_reporter = &micro_error_reporter;
  
  model = tflite::GetModel(g_model);
//  if (model->version() != TFLITE_SCHEMA_VERSION) {
//    error_reporter->Report(
//        "Model provided is schema version %d not equal "
//        "to supported version %d.",
//        model->version(), TFLITE_SCHEMA_VERSION);
//    return;
//   }

    static tflite::MicroMutableOpResolver<7> micro_op_resolver(error_reporter);
  if (micro_op_resolver.AddDepthwiseConv2D() != kTfLiteOk) {
    return;
  }
  if (micro_op_resolver.AddConv2D() != kTfLiteOk) {
    return;
  }
  if (micro_op_resolver.AddMaxPool2D() != kTfLiteOk) {
    return;
  }
  if(micro_op_resolver.AddAveragePool2D()!= kTfLiteOk) {
    return;
  }
  if (micro_op_resolver.AddFullyConnected() != kTfLiteOk) {
    return;
  }
  if (micro_op_resolver.AddSoftmax() != kTfLiteOk) {
    return;
  }
  if (micro_op_resolver.AddReshape() != kTfLiteOk) {
    return;
  }
  static tflite::MicroInterpreter static_interpreter(
      model, micro_op_resolver, tensor_arena, kTensorArenaSize,
      error_reporter);
  interpreter = &static_interpreter;
   TfLiteStatus allocate_status = interpreter->AllocateTensors();
  if (allocate_status != kTfLiteOk) {
    error_reporter->Report("AllocateTensors() failed");
    return;
  }

  model_input = interpreter->input(0);
  model_input_buffer = model_input->data.int8;
  output = interpreter->output(0);
  
  static FeatureProvider static_feature_provider(kFeatureElementCount,
      feature_buffer);
  feature_provider = &static_feature_provider;

}
int t1,t2;
double sum;
void loop() {
//    Serial.println("begin");
  const int32_t current_time = LatestTimes();
  int how_many_new_slices = 0;
//  Serial.println(current_time);
  TfLiteStatus feature_status = feature_provider->PopulateFeatureData(
      error_reporter, previous_time, current_time, &how_many_new_slices);
  if (feature_status != kTfLiteOk) {
    TF_LITE_REPORT_ERROR(error_reporter, "Feature generation failed");
    return;
  }

  previous_time = current_time;
  // If no new audio samples have been received since last time, don't bother
  // running the network model.
  if (how_many_new_slices == 0) {
    return;
//Serial.println(current_time);
  }
  for (int i = 0; i < kFeatureElementCount; i++) {
    model_input_buffer[i] = feature_buffer[i];
  }
    for(int i=0;i<kFeatureElementCount;i++)
   sum=sum+feature_buffer[i];
//    Serial.print("tb:");
//   Serial.println(sum/kFeatureElementCount);
   
//     Serial.println("invole");
   t1=micros();
    TfLiteStatus invoke_status = interpreter->Invoke();
    t2=micros();
  if (invoke_status != kTfLiteOk) {
    TF_LITE_REPORT_ERROR(error_reporter, "Invoke failed");
    return;
  }
//  Serial.println(t2);
 if (sum>-10){
   Serial.println(how_many_new_slices);
//  Serial.println(t2-t1);
  TfLiteTensor* output = interpreter->output(0);
   int8_t  scores0 = output->data.int8[0];
   int8_t scores1 = output->data.int8[1];
   int8_t  scores2 = output->data.int8[2];
//   int8_t scores3 = output->data.int8[3];
   int8_t z  = model_input->dims->data[1] ;
   int8_t y  = model_input->dims->data[2] ;
   Serial.print("no: ");
   Serial.println(scores0);
   Serial.print("unknow: ");
   Serial.println(scores1);
      Serial.print("yes: ");
   Serial.println(scores2);
//   Serial.print("Vo bac dan: ");
//   Serial.println(scores3);
 }


//     if(scores0>0)
//  { count[0]++;
//   }
//  if(scores1>0)
//  { count[1]++;
//   }
//  if(scores2>0)
//  { count[2]++;
//  }
//  if(scores3>0)
//  { count[3]++;
//  }
  for (int k = 0; k < kFeatureSliceSize ; k++) {
    for (int l = 0 ; l < kFeatureSliceCount ; l++ ) {
      Serial.print(feature_buffer[k * kFeatureSliceSize + l]);
      Serial.print("   ");
    }
    Serial.println(" ");
  }
  Serial.println(" ");
sum=0;
}
